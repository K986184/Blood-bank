<?php
// Include header file
include('include/header.php');

// Check if the session is already started, and start it if not
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Database connection
try {
    $db = new PDO('mysql:host=localhost;dbname=bbms', 'root', ''); // Update with your DB credentials
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>

<!-- Rest of your code... -->


<!-- Navbar -->
<nav id="mainNav" class="navbar fixed-top navbar-default navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="./index.php">DONATE_blood</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
    <!-- Centering the navbar items with a small adjustment -->
    <ul class="navbar-nav" style="margin-left: 20px; margin-right: 20px;">
      <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
      <li class="nav-item"><a class="nav-link" href="about.php">About Us</a></li>
      <li class="nav-item"><a class="nav-link" href="search.php">Search</a></li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <?php if(isset($_SESSION['name'])) echo $_SESSION['name']; ?>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="user/index.php"><i class="fa fa-user" aria-hidden="true"></i>Profile</a>
          <a class="dropdown-item" href="user/update.php"><i class="fa fa-edit" aria-hidden="true"></i>Update Profile</a>
          <a class="dropdown-item" href="user/logout.php"><i class="fa fa-arrow-circle-left" aria-hidden="true"></i>Logout</a>
        </div>
      </li>
    </ul>
  </div>
</nav>

<!-- Blood Stock Table -->
<div class="container" style="margin-top: 100px;">
    <h1 class="text-center">Stock of Blood List</h1>
    <center>
        <div id="form">
            <table border="1" cellpadding="10" cellspacing="0" style="width: 60%; margin: 20px auto; border-collapse: collapse; background-color: #8A1C1C; color: white;">
                <tr>
                    <td><center><b>Name</b></center></td>
                    <td><center><b>Quantity</b></center></td>
                </tr>

                <!-- Loop for blood groups -->
                <?php
                $blood_groups = ['O+', 'AB+', 'AB-', 'O-', 'A+', 'A-', 'B+', 'B-'];
                foreach ($blood_groups as $group) {
                    $q = $db->query("SELECT * FROM blood_stock WHERE blood_group='$group'");
                    $row = $q->fetch(PDO::FETCH_ASSOC);
                    echo "<tr><td><center>$group</center></td><td><center>{$row['units_available']}</center></td></tr>";
                }
                ?>
            </table>
        </div>
    </center>
</div>

<!-- Footer Section -->
<div id="footer" style="background-color: #8A1C1C; color: white; padding: 10px 0;">
    <h4 align="center">Blood Bank Project</h4>
    <p align="center"><a href="logout.php" style="color: black;">Logout</a></p>
</div>

<!-- Include footer file -->
<?php
include('include/footer.php');
?>
