<?php
// Include header file
include('include/header.php');

// Start session only if it's not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Database connection
try {
    $db = new PDO('mysql:host=localhost;dbname=bbms', 'root', ''); // Update with your DB credentials
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Validate and sanitize input
    $district = $_POST['district'] ?? null;
    $blood_group = $_POST['blood_group'] ?? null;
    $blood_units = $_POST['blood_units'] ?? null;

    if ($district && $blood_group && is_numeric($blood_units) && $blood_units > 0) {
        // Insert data into database
        $query = "INSERT INTO blood_requests (district, blood_group, blood_units) VALUES (:district, :blood_group, :blood_units)";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':district', $district);
        $stmt->bindParam(':blood_group', $blood_group);
        $stmt->bindParam(':blood_units', $blood_units);
        
        if ($stmt->execute()) {
            echo "<div class='alert alert-success'>Your blood request has been successfully submitted!</div>";
        } else {
            echo "<div class='alert alert-danger'>There was an error submitting your request. Please try again.</div>";
        }
    } else {
        echo "<div class='alert alert-warning'>Please fill out all fields correctly.</div>";
    }
}
?>
<!-- Blood Request Form -->
<div class="container-fluid header-img" style="background: url('img/bg.jpg') center center / cover no-repeat; padding: 100px 0;">
    <div class="row">
        <div class="col-md-6 offset-md-3 text-center">
            <h1 style="color: white; font-size: 48px; font-weight: bold;">Request Blood</h1>
            <p style="color: white; font-size: 18px; margin-top: 10px;">Please fill out the form below to request blood.</p>

            <form action="requestblood.php" method="POST" class="text-center mt-4">
                <!-- District Dropdown -->
                <div class="form-group d-inline-block" style="margin-right: 10px;">
                    <select name="district" id="district" class="form-control" style="width: 220px; height: 50px;" required>
                        <option value="">-- Select District --</option>
                        <optgroup label="Province 1">
                            <option value="Bhojpur">Bhojpur</option>
                            <option value="Dhankuta">Dhankuta</option>
                            <option value="Ilam">Ilam</option>
                            <option value="Jhapa">Jhapa</option>
                            <option value="Khotang">Khotang</option>
                            <option value="Morang">Morang</option>
                            <option value="Okhaldhunga">Okhaldhunga</option>
                            <option value="Panchthar">Panchthar</option>
                            <option value="Sankhuwasabha">Sankhuwasabha</option>
                            <option value="Solukhumbu">Solukhumbu</option>
                            <option value="Sunsari">Sunsari</option>
                            <option value="Taplejung">Taplejung</option>
                            <option value="Tehrathum">Tehrathum</option>
                            <option value="Udayapur">Udayapur</option>
                        </optgroup>
                        <optgroup label="Madhesh Province">
                            <option value="Bara">Bara</option>
                            <option value="Dhanusha">Dhanusha</option>
                            <option value="Mahottari">Mahottari</option>
                            <option value="Parsa">Parsa</option>
                            <option value="Rautahat">Rautahat</option>
                            <option value="Saptari">Saptari</option>
                            <option value="Sarlahi">Sarlahi</option>
                            <option value="Siraha">Siraha</option>
                        </optgroup>
                        <optgroup label="Bagmati Province">
                            <option value="Bhaktapur">Bhaktapur</option>
                            <option value="Chitwan">Chitwan</option>
                            <option value="Dhading">Dhading</option>
                            <option value="Dolakha">Dolakha</option>
                            <option value="Kathmandu">Kathmandu</option>
                            <option value="Kavrepalanchok">Kavrepalanchok</option>
                            <option value="Lalitpur">Lalitpur</option>
                            <option value="Makwanpur">Makwanpur</option>
                            <option value="Nuwakot">Nuwakot</option>
                            <option value="Ramechhap">Ramechhap</option>
                            <option value="Rasuwa">Rasuwa</option>
                            <option value="Sindhuli">Sindhuli</option>
                            <option value="Sindhupalchok">Sindhupalchok</option>
                        </optgroup>
                        <optgroup label="Gandaki Province">
                            <option value="Baglung">Baglung</option>
                            <option value="Gorkha">Gorkha</option>
                            <option value="Kaski">Kaski</option>
                            <option value="Lamjung">Lamjung</option>
                            <option value="Manang">Manang</option>
                            <option value="Mustang">Mustang</option>
                            <option value="Myagdi">Myagdi</option>
                            <option value="Nawalpur">Nawalpur</option>
                            <option value="Parbat">Parbat</option>
                            <option value="Syangja">Syangja</option>
                            <option value="Tanahun">Tanahun</option>
                        </optgroup>
                        <optgroup label="Lumbini Province">
                            <option value="Arghakhanchi">Arghakhanchi</option>
                            <option value="Banke">Banke</option>
                            <option value="Bardiya">Bardiya</option>
                            <option value="Dang">Dang</option>
                            <option value="Eastern Rukum">Eastern Rukum</option>
                            <option value="Gulmi">Gulmi</option>
                            <option value="Kapilvastu">Kapilvastu</option>
                            <option value="Parasi">Parasi</option>
                            <option value="Palpa">Palpa</option>
                            <option value="Pyuthan">Pyuthan</option>
                            <option value="Rolpa">Rolpa</option>
                            <option value="Rupandehi">Rupandehi</option>
                        </optgroup>
                        <optgroup label="Karnali Province">
                            <option value="Dailekh">Dailekh</option>
                            <option value="Dolpa">Dolpa</option>
                            <option value="Humla">Humla</option>
                            <option value="Jajarkot">Jajarkot</option>
                            <option value="Jumla">Jumla</option>
                            <option value="Kalikot">Kalikot</option>
                            <option value="Mugu">Mugu</option>
                            <option value="Salyan">Salyan</option>
                            <option value="Surkhet">Surkhet</option>
                            <option value="Western Rukum">Western Rukum</option>
                        </optgroup>
                        <optgroup label="Sudurpashchim Province">
                            <option value="Achham">Achham</option>
                            <option value="Baitadi">Baitadi</option>
                            <option value="Bajhang">Bajhang</option>
                            <option value="Bajura">Bajura</option>
                            <option value="Dadeldhura">Dadeldhura</option>
                            <option value="Darchula">Darchula</option>
                            <option value="Doti">Doti</option>
                            <option value="Kailali">Kailali</option>
                            <option value="Kanchanpur">Kanchanpur</option>
                        </optgroup>
                    </select>
                </div>

                <!-- Blood Group Dropdown -->
                <div class="form-group center-aligned">
                    <select name="blood_group" id="blood_group" style="padding: 0 20px; width: 220px; height: 45px;" class="form-control demo-default text-center margin10px" required>
                        <option value="">-- Select Blood Group --</option>
                        <option value="A+">A+</option>
                        <option value="A-">A-</option>
                        <option value="B+">B+</option>
                        <option value="B-">B-</option>
                        <option value="AB+">AB+</option>
                        <option value="AB-">AB-</option>
                        <option value="O+">O+</option>
                        <option value="O-">O-</option>
                    </select>
                </div>

                <!-- Blood Units -->
                <div class="form-group center-aligned">
                    <input type="number" name="blood_units" class="form-control" placeholder="Enter Blood Units" style="width: 220px; height: 45px;" required min="1">
                </div>

                <!-- Submit Button -->
                <div class="form-group center-aligned">
                    <button type="submit" class="btn btn-lg btn-danger">Submit Request</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
// Include footer file
include('include/footer.php');
?>
