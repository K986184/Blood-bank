<?php
    $connection = mysqli_connect("localhost","root","","bbms") or
    die("Database is not connected.". mysqli_connect_error());

 ?>
